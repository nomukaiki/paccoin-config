#!/bin/bash
HOME=_HOME_
cd _HOME_/sentinel && ./venv/bin/python bin/sentinel.py